<ul class="nav nav-tabs">
    <li class="nav-item"><a class="nav-link" href="/admin/course/view/{{$course->id}}">Content</a></li>
    <li class="nav-item"><a class="nav-link active" aria-current="page" href="/admin/content/add/{{$course->id}}">Add Content</a></li>
    <li class="nav-item"><a class="nav-link" href="/admin/course/student/{{$course->id}}">Student List</a></li>
</ul>