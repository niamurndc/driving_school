

<?php $__env->startSection('title'); ?>
    <title><?php echo e($title); ?></title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


<section id="about" class="py-5">
    <div class="container py-4">
        <h2><?php echo e($title); ?></h2>
        <?php echo $page; ?>

    </div>
</section>

<section id="useful-link" class="py-5 bg-deep">
    <div class="container">
        <h2 class="text-white text-center mb-4">Useful Links</h2>
        <div class="row">
            <?php $__currentLoopData = App\Models\UsefulLink::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <a href="<?php echo e($link->link); ?>" target="blank" class="text-white useful-link"><?php echo e($link->text); ?></a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Development\Laravel\driving_school\resources\views/page.blade.php ENDPATH**/ ?>