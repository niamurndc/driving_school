<ul class="nav nav-tabs">
    <li class="nav-item"><a class="nav-link" href="/admin/course/view/<?php echo e($course->id); ?>">Content</a></li>
    <li class="nav-item"><a class="nav-link active" aria-current="page" href="/admin/content/add/<?php echo e($course->id); ?>">Add Content</a></li>
    <li class="nav-item"><a class="nav-link" href="/admin/course/student/<?php echo e($course->id); ?>">Student List</a></li>
</ul><?php /**PATH C:\Development\Laravel\driving_school\resources\views/partials/course-nav.blade.php ENDPATH**/ ?>