

<?php $__env->startSection('content'); ?>
<div class="card border-light bg-light px-3 mb-4">
  <div class="d-flex justify-content-between align-items-center">
    <h2>Courses</h2>
    <a href="/admin/course/create" class="btn btn-primary">Add New</a>
  </div>
  
</div>

<div class="container">

  <div class="card px-3 py-3 mt-5">
    <h6 class="mb-3">All Courses</h6>
    <table class="table table-striped" id="example">
      <thead>
        <tr>
          <th scope="col">Image</th>
          <th scope="col">Title</th>
          <th scope="col">Slug</th>
          <th scope="col">Price</th>
          <th scope="col">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><img src="/uploads/course/<?php echo e($course->image); ?>" alt="Image" height="40px" width="40px"></td>
          <td><?php echo e($course->title); ?></td>
          <td><?php echo e($course->slug); ?></td>
          <td><?php echo e($course->price); ?> <br> <strike><?php echo e($course->offprice); ?></strike></td>
          <td>
            <a href="/admin/course/view/<?php echo e($course->id); ?>" class="btn btn-warning btn-sm"><i class="fa fa-eye"></i></a>
            <a href="/admin/course/edit/<?php echo e($course->id); ?>" class="btn btn-primary btn-sm"><i class="fa fa-pencil"></i></a>
            <a href="/admin/course/delete/<?php echo e($course->id); ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash" onClick="return confirm('Are you want to delete?')"></i></a>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Development\Laravel\driving_school\resources\views/admin/course/index.blade.php ENDPATH**/ ?>