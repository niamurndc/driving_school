

<?php $__env->startSection('title'); ?>
    <title>কনটেন্ট | <?php echo e($course->title); ?></title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="bg-black text-white">
    <div class="container py-3 py-md-4 content">
        <?php if($content->type == 'image'): ?>
        <img src="/uploads/content/<?php echo e($content->image); ?>" alt="content image" width="100%">
        <?php elseif($content->type == 'youtube'): ?>
        
        <?php echo $content->desc; ?>

        <?php else: ?>
        <div class="card p-4 text-black">
            <?php echo $content->desc; ?>

        </div>
        <?php endif; ?>
    </div>
</div>


<div class="container py-4">
    <div class="row p-1">
        <div class="col-md-8">

            <div class="card p-4 mb-4">
                <h3 class="text-deep mb-4">কোর্স এর কনটেন্ট</h3>
                <ul class="list-group">
                    <?php $__currentLoopData = $course->contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <?php if($content->type == 'article'): ?>
                            <i class="fa fa-file-text-o me-3"></i>
                            <?php elseif($content->type == 'youtube'): ?>
                            <i class="fa fa-youtube me-3"></i>
                            <?php else: ?>
                            <i class="fa fa-file-image-o me-3"></i>
                            <?php endif; ?>
                            <a class="text-dark" href="/course/<?php echo e($course->slug); ?>/content/<?php echo e($content->id); ?>"><?php echo e($content->title); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

        </div>
        <div class="col-md-4">

            <div class="card p-4 mb-4">
                <h3 class="text-deep mb-4">কোর্স এর পরীক্ষা সমূহ</h3>
                    <?php $__currentLoopData = App\Models\Exam::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><i class="fa fa-sticky-note-o"></i> <b> <a href="/exam/<?php echo e($exam->id); ?>" class="text-black"><?php echo e($exam->title); ?></a></b></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>


<?php echo $__env->make('partials.useful-link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Development\Laravel\driving_school\resources\views/content.blade.php ENDPATH**/ ?>