

<?php $__env->startSection('content'); ?>
<div class="card border-light bg-light px-3 mb-4">
  <div class="d-flex justify-content-between align-items-center">
    <h2><?php echo e($exam->title); ?></h2>
    <a href="/admin/courses" class="btn btn-primary">Back</a>
  </div>
  
</div>

<div class="container">
  <div class="row justify-content-center">

    <div class="col-md-8">
      <div class="card mb-4 p-3">
        <p><?php echo e($exam->desc); ?></p>
      </div>
      <div class="card px-3 py-3 mb-5">
        <h6 class="mb-3">Add Question</h6>
        <form action="/admin/exam-question/add/<?php echo e($exam->id); ?>" method="post" enctype="multipart/form-data">
          <?php echo csrf_field(); ?> 
          <div class="row">
            <div class="form-group col-md-8 mb-4">
                <label for="text">Question Text</label>
                <input type="text" name="text" id="text" class="form-control <?php $__errorArgs = ['text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('text')); ?>" required>
                <?php $__errorArgs = ['text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <p><?php echo e($message); ?></p>
                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group col-md-4 mb-4">
                <label for="desc">Answer (correct option)</label>
                <select name="ans" id="ans" class="form-control" required>
                    <option value="1">Option 1</option>
                    <option value="2">Option 2</option>
                    <option value="3">Option 3</option>
                    <option value="4">Option 4</option>
                </select>
            </div>


            <div class="form-group col-md-6 mb-4">
                <label for="option1">Option 1</label>
                <input type="text" name="option1" id="option1" class="form-control <?php $__errorArgs = ['option1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('option1')); ?>" required>
                <?php $__errorArgs = ['option1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <p><?php echo e($message); ?></p>
                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group col-md-6 mb-4">
                <label for="option2">Option 2</label>
                <input type="text" name="option2" id="option2" class="form-control <?php $__errorArgs = ['option2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('option2')); ?>" required>
                <?php $__errorArgs = ['option2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <p><?php echo e($message); ?></p>
                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group col-md-6 mb-4">
                <label for="option3">Option 3</label>
                <input type="text" name="option3" id="option3" class="form-control <?php $__errorArgs = ['option3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('option3')); ?>" required>
                <?php $__errorArgs = ['option3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <p><?php echo e($message); ?></p>
                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group col-md-6 mb-4">
                <label for="option4">Option 4</label>
                <input type="text" name="option4" id="option4" class="form-control <?php $__errorArgs = ['option4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('option4')); ?>" required>
                <?php $__errorArgs = ['option4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <p><?php echo e($message); ?></p>
                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6 text-left">
              <button type="submit" class="btn btn-primary">Create</button>
            </div>
          </div>
        </form>
      </div>

      <div class="card mb-4 p-3">
          <?php $i = 1; ?>
            <?php $__currentLoopData = $exam->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><b><?php echo e($i); ?></b> <?php echo e($question->text); ?> <b>Correct ans: <?php echo e($question->ans); ?></b> <a href="/admin/exam-question/delete/<?php echo e($question->id); ?>" class="btn btn-danger btn-sm">Delete</a></p> 
                <div class="row">
                    <div class="col-md-6">
                        <p>A: <?php echo e($question->option1); ?></p>
                    </div>
                    <div class="col-md-6">
                        <p>B: <?php echo e($question->option2); ?></p>
                    </div>
                    <div class="col-md-6">
                        <p>C: <?php echo e($question->option3); ?></p>
                    </div>
                    <div class="col-md-6">
                        <p>D: <?php echo e($question->option4); ?></p>
                    </div>
                </div>
                <hr>
                <?php $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function(){
        $('#add_mat').click(function(){
            var par = '<div class="form-group col-md-8 mb-2"><input type="text" name="material[]" class="form-control" required></div>';
            $('#mat-box').append(par);
        });

        $('#remove_mat').click(function(){
            var child = $('#mat-box').children();
            if(child.length > 3){
                $('#mat-box').children().last().remove();
            }
        });

        $('#add_fet').click(function(){
            var par2 = '<div class="form-group col-md-8 mb-2"><input type="text" name="feature[]" class="form-control" required></div>';
            $('#fet-box').append(par2);
        });

        $('#remove_fet').click(function(){
            var child = $('#fet-box').children();
            if(child.length > 3){
                $('#fet-box').children().last().remove();
            }
        })
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Development\Laravel\driving_school\resources\views/admin/exam/view.blade.php ENDPATH**/ ?>