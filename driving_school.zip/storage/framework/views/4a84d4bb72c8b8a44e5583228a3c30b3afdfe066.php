

<?php $__env->startSection('title'); ?>
    <title><?php echo e($exam->title); ?></title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>



<section id="about" class="py-5">
    <div class="container py-4">
        <div class="card p-4">
            <div class="row">
                <div class="col-md-9">
                    <h2 class="text-deep mb-4"><?php echo e($exam->title); ?></h2>
                    <p><?php echo e($exam->desc); ?></p>
                </div>
                <div class="col-md-3"> 
                    <h4>পূর্ণমান: <?php echo e($exam->total); ?> | পাস্ নম্বর: <?php echo e($exam->pass); ?></h4>
                </div>
            </div>
            
        </div>

        <div class="card py-5">
            <div class="py-5 text-center">
                
                <?php if($marks >= $exam->pass): ?>
                <h1 class="text-success"><i class="fa fa-check-circle"></i></h1>
                <h2 class="text-success">সফল হয়েছেন</h2>
                <?php else: ?>
                <h1 class="text-danger"><i class="fa fa-times-circle"></i></h1>
                <h2 class="text-danger">আবার চেষ্ঠা করুন</h2>
                <?php endif; ?>

                <h4>আপনার নম্বর: <?php echo e($marks); ?></h4>
            </div>
        </div>
        
    </div>

    
</section>

<?php echo $__env->make('partials.useful-link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Development\Laravel\driving_school\resources\views/exam/result.blade.php ENDPATH**/ ?>