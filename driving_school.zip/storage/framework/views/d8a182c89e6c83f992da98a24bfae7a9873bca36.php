

<?php $__env->startSection('title'); ?>
    <title>Welcome </title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<section id="about" class="py-5">
    <div class="container py-4">
        <h2 class="text-center mb-5">আপনার কোর্সসমূহ</h2>

        <div class="card p-4 bg-light">
            <div class="row">
                <?php $__currentLoopData = $enrolls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enroll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($enroll->course_id != null): ?>
                <div class="col-md-3">
                    <div class="card">
                        <img src="/uploads/course/<?php echo e($enroll->course->image); ?>" alt="image" width="100%" height="210px">
                        <div class="card-body p-2 mt-4">
                            <a href="/course/<?php echo e($enroll->course->slug); ?>" class="course-title mb-2"><?php echo e($enroll->course->title); ?></a>


                            <div class="text-center pt-2 border-top">
                                    <h5 class="text-deep"><b><a class="text-deep" href="/course/<?php echo e($enroll->course->slug); ?>">View Course</a></b></h5>
                            </div>
                            
                        </div>
                    </div>
                </div>
                <?php else: ?>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Development\Laravel\driving_school\resources\views/user/course.blade.php ENDPATH**/ ?>