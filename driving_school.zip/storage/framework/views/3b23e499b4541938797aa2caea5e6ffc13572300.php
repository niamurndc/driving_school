

<?php $__env->startSection('title'); ?>
    <title><?php echo e($course->title); ?></title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="bg-black text-white">
    <div class="container py-5">
        <div class="row p-1">
            <div class="col-md-8 py-4">
                <h1><b><?php echo e($course->title); ?></b></h1>
                <h5 class="mt-5"><i class="fa fa-user-o"></i> <?php echo e(count($course->students)); ?> Students</h5>
                <h5><i class="fa fa-clock-o"></i> Uploaded: <?php echo e($course->updated_at); ?></h5>


                <?php if(count(App\Models\Enrollment::where('student_id', auth()->user()->id)->where('course_id', $course->id)->get()) == 0): ?>
                <a href="/enrollment/<?php echo e($course->id); ?>" class="btn btn-lg btn-info text-black mt-5"><i class="fa fa-shopping-cart"></i> এই কোর্স এ ভর্তি হোন</a>

                <?php endif; ?>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <img src="/uploads/course/<?php echo e($course->image); ?>" alt="course-image" width="100%" height="
                240px">

                <h1 class="mt-4 text-dark"><b>৳ <?php echo e($course->price); ?> </b><strike><?php echo e($course->cprice); ?></strike></h1>
                </div>

            </div>
        </div>
    </div>
</div>


<div class="container py-4">
    <div class="row p-1">
        <div class="col-md-8">
            <div class="card p-4 mb-4">
                <h3 class="text-deep mb-4">এই কোর্স এ যা রয়েছে</h3>
                <div class="row">
                    <?php $__currentLoopData = json_decode($course->feature); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6">
                        <p><i class="fa fa-check-circle"></i> <?php echo e($feature); ?></p>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div class="card p-4 mb-4">
                <h3 class="text-deep mb-4">কোর্স এর বিস্তারিত</h3>
                <?php echo $course->desc; ?>

            </div>

            <div class="card p-4 mb-4">
                <h3 class="text-deep mb-4">কোর্স এর কনটেন্ট</h3>
                <ul class="list-group">
                    <?php $__currentLoopData = $course->contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <?php if($content->type == 'article'): ?>
                            <i class="fa fa-file-text-o me-3"></i>
                            <?php elseif($content->type == 'youtube'): ?>
                            <i class="fa fa-youtube me-3"></i>
                            <?php else: ?>
                            <i class="fa fa-file-image-o me-3"></i>
                            <?php endif; ?>
                            <a class="text-dark" href="/course/<?php echo e($course->slug); ?>/content/<?php echo e($content->id); ?>"><?php echo e($content->title); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

        </div>
        <div class="col-md-4">
            <div class="card p-4 mb-4">
                <h3 class="text-deep mb-4">ফিচার সমূহ</h3>
                <?php $__currentLoopData = json_decode($course->material); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><i class="fa fa-check"></i> <b> <?php echo e($material); ?></b></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="card p-4 mb-4">
                <h3 class="text-deep mb-4">পরীক্ষা সমূহ</h3>
                <?php if(count(App\Models\Enrollment::where('student_id', auth()->user()->id)->where('course_id', $course->id)->where('status', 1)->get()) != 0): ?>
                    <?php $__currentLoopData = App\Models\Exam::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><i class="fa fa-sticky-note-o"></i> <b> <a href="/exam/<?php echo e($exam->id); ?>" class="text-black"><?php echo e($exam->title); ?></a></b></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <p>অনুমোদন এর জন্য অপেক্ষা করুন</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>


<?php echo $__env->make('partials.useful-link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Development\Laravel\driving_school\resources\views/course-view.blade.php ENDPATH**/ ?>