<?php echo e($slot); ?>

<?php /**PATH C:\Development\Laravel\driving_school\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>