

<?php $__env->startSection('title'); ?>
    <title>Welcome </title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.front-slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section id="about" class="py-5">
    <div class="container py-4">
        <h2 class="text-center mb-5">আমাদের কোর্সসমূহ</h2>
        <div class="row">

        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3">
            <div class="card">
                <img src="/uploads/course/<?php echo e($course->image); ?>" alt="image" width="100%" height="210px">
                <div class="card-body p-2 mt-4">
                    <a href="/course/<?php echo e($course->slug); ?>" class="course-title mb-2"><?php echo e($course->title); ?></a>

                    <p class="text-dark"><i class="fa fa-user-o me-2"></i> <b><?php echo e(count($course->students)); ?> </b>Students</p>
                    <div class="row pt-2 border-top">
                        <div class="col-7">
                            <h5 class="text-deep"><b>৳ <?php echo e($course->price); ?> </b> <strike><?php echo e($course->cprice); ?></strike></h5>
                        </div>
                        <div class="col-5 text-end">
                            <h5 class="text-deep"><a class="text-deep" href="/course/<?php echo e($course->slug); ?>">ভর্তি হোন</a></h5>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</section>

<?php echo $__env->make('partials.useful-link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Development\Laravel\driving_school\resources\views/course.blade.php ENDPATH**/ ?>