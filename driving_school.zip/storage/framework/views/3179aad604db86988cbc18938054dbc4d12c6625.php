

<?php $__env->startSection('content'); ?>
<div class="card border-light bg-light px-3 mb-4">
  <div class="d-flex justify-content-between align-items-center">
    <h2>Courses</h2>
    <a href="/admin/courses" class="btn btn-primary">Back</a>
  </div>
  
</div>

<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8">

      <div class="card px-3 py-3 mb-5">
        <h6 class="mb-3">Add Course</h6>
        <form action="/admin/course/create" method="post" enctype="multipart/form-data">
          <?php echo csrf_field(); ?> 
          <div class="row">
            <div class="form-group col-md-6 mb-4">
                <label for="title">Title</label>
                <input type="text" name="title" id="title" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('title')); ?>">
                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <p><?php echo e($message); ?></p>
                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-md-6 mb-4">
                <label for="image">Image</label>
                <input type="file" name="image" id="image" class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <p><?php echo e($message); ?></p>
                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group col-md-6 mb-4">
                <label for="price">Price</label>
                <input type="number" name="price" id="price" class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('price')); ?>">
                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <p><?php echo e($message); ?></p>
                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-md-6 mb-4">
                <label for="cprice">Compare Price (see with <strike>cross</strike>) optional</label>
                <input type="number" name="cprice" id="cprice" class="form-control <?php $__errorArgs = ['cprice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('cprice')); ?>">
                <?php $__errorArgs = ['cprice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <p><?php echo e($message); ?></p>
                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>



            <div class="form-group col-md-12 mb-4">
                <label for="desc">Description</label>
                <textarea name="desc" id="desc" rows="4" class="form-control"><?php echo e(old('desc')); ?></textarea>
            </div>

            

            <div class="col-md-12 mb-4">
                <h6>Materials Includes</h6>
                <?php $__errorArgs = ['material'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger mb-2"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="row p-2" id="mat-box">
                    <div class="form-group col-8 mb-2">
                        <input type="text" name="material[]" class="form-control" required>
                    </div>
                    <div class="col-2">
                        <p id="add_mat" class="btn btn-success text-light"><i class="fa fa-plus"></i></p>
                    </div>
                    <div class="col-2">
                        <p id="remove_mat" class="btn btn-danger text-light"><i class="fa fa-times"></i></p>
                    </div>
                </div>
            </div>

            <div class="col-md-12 mb-4">
                <h6>Learn and Feature</h6>
                <?php $__errorArgs = ['feature'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger mb-2"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="row p-2" id="fet-box">
                    <div class="form-group col-md-8 mb-2">
                        <input type="text" name="feature[]" class="form-control" required>
                    </div>
                    <div class="col-md-2">
                        <p id="add_fet" class="btn btn-success text-light"><i class="fa fa-plus"></i></p>
                    </div>
                    <div class="col-2">
                        <p id="remove_fet" class="btn btn-danger text-light"><i class="fa fa-times"></i></p>
                    </div>
                </div>
            </div>

            <div class="col-md-6 text-left">
              <button type="submit" class="btn btn-primary mt-4">Create</button>
            </div>
          </div>
        </form>
      </div>

      </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function(){
        $('#add_mat').click(function(){
            var par = '<div class="form-group col-md-8 mb-2"><input type="text" name="material[]" class="form-control" required></div>';
            $('#mat-box').append(par);
        });

        $('#remove_mat').click(function(){
            var child = $('#mat-box').children();
            if(child.length > 3){
                $('#mat-box').children().last().remove();
            }
        });

        $('#add_fet').click(function(){
            var par2 = '<div class="form-group col-md-8 mb-2"><input type="text" name="feature[]" class="form-control" required></div>';
            $('#fet-box').append(par2);
        });

        $('#remove_fet').click(function(){
            var child = $('#fet-box').children();
            if(child.length > 3){
                $('#fet-box').children().last().remove();
            }
        })
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Development\Laravel\driving_school\resources\views/admin/course/add.blade.php ENDPATH**/ ?>