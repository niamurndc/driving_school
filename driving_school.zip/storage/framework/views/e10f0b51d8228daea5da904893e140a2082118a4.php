

<?php $__env->startSection('title'); ?>
    <title><?php echo e($exam->title); ?></title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>



<section id="about" class="py-5">
    <div class="container py-4">
        <div class="card p-4">
            <div class="row">
                <div class="col-md-9">
                    <h2 class="text-deep mb-4"><?php echo e($exam->title); ?></h2>
                    <p><?php echo e($exam->desc); ?></p>
                </div>
                <div class="col-md-3">
                    <h3 class="text-success">সময়: <span id="timec"><?php echo e($exam->time); ?></span> Minute</h3>   
                    <h4>পূর্ণমান: <?php echo e($exam->total); ?> | পাস্ নম্বর: <?php echo e($exam->pass); ?></h4>
 
                </div>
            </div>
            
        </div>
        
        <div class="card p-4">
            <?php $i = 1; ?>
            <form action="/exam/<?php echo e($exam->id); ?>" method="post" id="exam-form"> <?php echo csrf_field(); ?> 
            <?php $__currentLoopData = $exam->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><b><?php echo e($i); ?>.</b> <?php echo e($question->text); ?></p>

                <div class="form-check">
                    <input class="form-check-input" type="radio" name="option<?php echo e($i); ?>" id="<?php echo e($question->id); ?>" value="1">
                    <label class="form-check-label" for="<?php echo e($question->id); ?>">
                        A: <?php echo e($question->option1); ?>

                    </label>
                <div class="form-check">
                </div>
                    <input class="form-check-input" type="radio" name="option<?php echo e($i); ?>" id="<?php echo e($question->id); ?>" value="2">
                    <label class="form-check-label" for="<?php echo e($question->id); ?>">
                        B: <?php echo e($question->option2); ?>

                    </label>
                <div class="form-check">
                </div>
                    <input class="form-check-input" type="radio" name="option<?php echo e($i); ?>" id="<?php echo e($question->id); ?>" value="3">
                    <label class="form-check-label" for="<?php echo e($question->id); ?>">
                        C: <?php echo e($question->option3); ?>

                    </label>
                <div class="form-check">
                </div>
                    <input class="form-check-input" type="radio" name="option<?php echo e($i); ?>" id="<?php echo e($question->id); ?>" value="4">
                    <label class="form-check-label" for="<?php echo e($question->id); ?>">
                        D: <?php echo e($question->option4); ?>

                    </label>
                </div>
                <hr>
                <?php $i++; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <button type="submit" class="btn btn-info">সাবমিট</button>
            </form>
        </div>
        
    </div>

    
</section>

<?php echo $__env->make('partials.useful-link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script>
    let timeText = document.getElementById('timec');

    const getTime = timeText.innerText;
    let time = getTime * 60;

    setInterval(function(){
        time--;

        let minute = Math.floor(time / 60);
        let second = time % 60;
        console.log(minute + ':' + second);
        timeText.innerHTML = minute + ':' + second;

        if(time == 0){
            document.getElementById('exam-form').submit();
        }
    }, 1000);
    
    const sum = 1.88 - .01;
    console.log(sum);
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Development\Laravel\driving_school\resources\views/exam/index.blade.php ENDPATH**/ ?>