

<?php $__env->startSection('title'); ?>
    <title>Welcome </title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>



<section id="about" class="py-5">
    <div class="container py-4">
        <h2 class="text-deep mb-4">তথ্য মূলক চিহ্ন</h2>
        <div class="row">
            <?php $__currentLoopData = $icons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $icon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($icon->section == 1): ?>
                <div class="col-4 col-sm-3 col-md-2 col-lg-1 text-center">
                    <img src="/uploads/icon/<?php echo e($icon->image); ?>" alt="icon" width="100%">
                    <h6><?php echo e($icon->title); ?></h6>
                </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="container py-4">
        <h2 class="text-deep mb-4">বাধ্যতামূলক হ্যা বোধক চিহ্ন</h2>
        <div class="row">
            <?php $__currentLoopData = $icons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $icon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($icon->section == 2): ?>
                <div class="col-4 col-sm-3 col-md-2 col-lg-1 text-center">
                    <img src="/uploads/icon/<?php echo e($icon->image); ?>" alt="icon" width="100%">
                    <h6><?php echo e($icon->title); ?></h6>
                </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="container py-4">
        <h2 class="text-deep mb-4">বাধ্যতামূলক না বোধক চিহ্ন</h2>
        <div class="row">
            <?php $__currentLoopData = $icons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $icon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($icon->section == 3): ?>
                <div class="col-4 col-sm-3 col-md-2 col-lg-1 text-center">
                    <img src="/uploads/icon/<?php echo e($icon->image); ?>" alt="icon" width="100%">
                    <h6><?php echo e($icon->title); ?></h6>
                </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="container py-4">
        <h2 class="text-deep mb-4">সতর্কতামূলক চিহ্ন</h2>
        <div class="row">
            <?php $__currentLoopData = $icons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $icon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($icon->section == 4): ?>
                <div class="col-4 col-sm-3 col-md-2 col-lg-1 text-center">
                    <img src="/uploads/icon/<?php echo e($icon->image); ?>" alt="icon" width="100%">
                    <h6><?php echo e($icon->title); ?></h6>
                </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<?php echo $__env->make('partials.useful-link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Development\Laravel\driving_school\resources\views/road-sign.blade.php ENDPATH**/ ?>