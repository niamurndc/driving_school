

<?php $__env->startSection('content'); ?>
<div class="card border-light bg-light px-3 mb-4">
  <div class="d-flex justify-content-between align-items-center">
    <h2>Useful Links</h2>
    <a href="/admin/link/create" class="btn btn-primary">Add New</a>
  </div>
  
</div>

<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8">

      <div class="card px-3 py-3 mt-5">
        <h6 class="mb-3">All Useful Links</h6>
        <table class="table table-striped" id="example">
          <thead>
            <tr>
              <th scope="col">Text</th>
              <th scope="col">Link</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
          <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($link->text); ?></td>
              <td><a target="blank" href="<?php echo e($link->link); ?>"><?php echo e($link->link); ?></a></td>
              <td>
                <a href="/admin/link/edit/<?php echo e($link->id); ?>" class="btn btn-primary btn-sm"><i class="fa fa-pencil"></i></a>
                <a href="/admin/link/delete/<?php echo e($link->id); ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash" onClick="return confirm('Are you want to delete?')"></i></a>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Development\Laravel\driving_school\resources\views/admin/link/index.blade.php ENDPATH**/ ?>