

<?php $__env->startSection('title'); ?>
    <title>Welcome </title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<section id="about" class="py-5">
    <div class="container py-4">
        <h2 class="text-center mb-5">আপনার সার্টিফিকেট</h2>

        <div class="card p-4 bg-light">
            <table class="table-responsive">
                <thead>
                    <tr>
                        <th></th>
                        <th>Course Title</th>
                        <th>Your Marks</th>
                        <th>Certificate</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $enrolls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enroll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($enroll->course_id != null): ?>
                    <tr>
                        <td><img src="/uploads/course/<?php echo e($enroll->course->image); ?>" height="80px" width="120px"></td>
                        <td><?php echo e($enroll->course->title); ?></td>
                        <td><?php echo e($enroll->marks); ?></td>
                        <td><?php if($enroll->certificate == 1): ?> <a href="/get-certificate/<?php echo e($enroll->id); ?>" class="text-deep">ডাউনলোড</a> <?php else: ?> নাই <?php endif; ?></td>
                    </tr>
                    <?php else: ?>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Development\Laravel\driving_school\resources\views/user/certificate.blade.php ENDPATH**/ ?>