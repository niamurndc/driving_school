<section id="useful-link" class="py-5 bg-deep">
    <div class="container">
        <h2 class="text-white text-center mb-4">জরুরী লিংকসমূহ</h2>
        <div class="row">
            <?php $__currentLoopData = App\Models\UsefulLink::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <a href="<?php echo e($link->link); ?>" target="blank" class="text-white useful-link"><?php echo e($link->text); ?></a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section><?php /**PATH C:\Development\Laravel\driving_school\resources\views/partials/useful-link.blade.php ENDPATH**/ ?>