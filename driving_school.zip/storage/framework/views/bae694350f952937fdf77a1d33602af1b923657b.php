

<?php $__env->startSection('title'); ?>
    <title>নোটিশ</title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>



<section id="about" class="py-5">
    <div class="container py-4">
        <h2 class="text-deep mb-4">নোটিশ</h2>
        <?php $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card p-4 mb-4">
            <h4 class="text-center"><?php echo e($notice->title); ?></h4>
            <div class="border-top pt-4">
                <?php echo e($notice->desc); ?>

            </div>
        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
</section>

<?php echo $__env->make('partials.useful-link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Development\Laravel\driving_school\resources\views/notice.blade.php ENDPATH**/ ?>