

<?php $__env->startSection('title'); ?>
    <title>কোর্সে ভর্তি | <?php echo e($course->title); ?></title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="card">
        <div class="row p-2">
            <div class="col-md-9 py-4">
                <h3><b><?php echo e($course->title); ?></b></h3>
                <h5 class="mt-4"><i class="fa fa-user-o"></i> <?php echo e(count($course->students)); ?> Students</h5>
                <h2 class="mt-2 text-dark"><b>৳ <?php echo e($course->price); ?> </b></h2>
            </div>
            <div class="col-md-3">
                    <img src="/uploads/course/<?php echo e($course->image); ?>" alt="course-image" width="100%" height="
                210px">
            </div>
        </div>
    </div>
    

    <div class="card mt-4 p-4">
        <h4 class="text-deep">কোর্সে ভর্তির জন্য ফরমটি পূরণ করুন</h4>
        <form action="/enrollment/<?php echo e($course->id); ?>" method="post"> <?php echo csrf_field(); ?>
            <div class="col-md-6">
                <div class="form-group mb-4">
                    <label for="name">নাম</label>
                    <input type="text" name="name" id="name" class="form-control" readonly value="<?php echo e(auth()->user()->name); ?>">
                </div>
                <div class="form-group mb-4">
                    <label for="phone">ফোন</label>
                    <input type="text" name="phone" id="phone" class="form-control" readonly value="<?php echo e(auth()->user()->phone); ?>">
                </div>

                <div class="form-group mb-4">
                    <label for="amount">টাকার পরিমান</label>
                    <input type="number" name="amount" id="amount" class="form-control" readonly value="<?php echo e($course->price); ?>">
                </div>

                <p><b>নিচের যে কোনো একটি নম্বর টাকা পাঠান</b></p>
                <p>বিকাশ পার্সোনাল: ০২৬৫৪৭৮৯৩১</p>
                <p>নাগদ পার্সোনাল: ০২৬৫৪৭৮৯৩১</p>
                <p>রকেট পার্সোনাল: ০২৬৫৪৭৮৯৩১</p>
                <div class="form-group mb-4">
                    <label for="method">যে নম্বর এ টাকা দিয়েছেন</label>
                    <select name="method" id="method" class="form-control <?php $__errorArgs = ['method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <option value="">Select</option>
                        <option value="bkash">Bkash</option>
                        <option value="nagad">Nagad</option>
                        <option value="Rocket">Rocket</option>
                    </select>
                    <?php $__errorArgs = ['method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group mb-4">
                    <label for="phone">যে নম্বর থেকে টাকা পাঠিয়েছেন (লাস্ট ৪ নম্বর)</label>
                    <input type="text" name="phone" id="phone" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="form-check mb-4">
                    <input class="form-check-input" type="checkbox" required id="flexCheckIndeterminate">
                    <label class="form-check-label" for="flexCheckIndeterminate">
                        আমি <a href="/terms">শর্তাবলীর</a> সাথে একমত
                    </label>
                </div>

                <button type="submit" class="btn btn-info">কন্ফার্ম</button>
            </div>
        </form>
    </div>
</div>






<?php echo $__env->make('partials.useful-link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Development\Laravel\driving_school\resources\views/enrollment.blade.php ENDPATH**/ ?>