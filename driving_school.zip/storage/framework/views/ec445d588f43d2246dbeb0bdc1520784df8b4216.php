

<?php $__env->startSection('content'); ?>
<div class="card border-light bg-light px-3 mb-4">
  <div class="d-flex justify-content-between align-items-center">
    <h2>Backups</h2>
    <a href="/admin/backup/create" class="btn btn-primary"><i class="fa fa-plus-circle"></i> Create Backup</a>
  </div>
  
</div>

<div class="container">

  <div class="card px-3 py-3 mt-5">
    <div class="row mb-4">
      <div class="col-md-6">
        <h6 class="mb-3">Backups List</h6>
      </div>
    </div>



    <table class="table table-striped">
      <thead>
        <tr>
          <th scope="col">Time</th>
          <th scope="col">File</th>
          <th scope="col">Size</th>
          <th scope="col">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $backups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $backup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($backup['created_at']); ?></td>
          <td><?php echo e($backup['file_name']); ?></td>
          <td><?php echo e($backup['file_size']); ?></td>
          <td><a href="/admin/backup/download/<?php echo e($backup['file_name']); ?>" class="btn btn-success btn-sm"><i class="fa fa-download"></i></a>
            <a href="/admin/backup/delete/<?php echo e($backup['file_name']); ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash" onClick="return confirm('Are you want to delete?')"></i></a>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>

  </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Development\Laravel\driving_school\resources\views/admin/backup.blade.php ENDPATH**/ ?>